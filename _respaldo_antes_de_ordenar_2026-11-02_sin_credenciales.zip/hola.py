

import os
import json
import pathlib


tabpfn_cfg_dir  = pathlib.Path.home() / ".tabpfn"
tabpfn_cfg_dir.mkdir(exist_ok=True)
tabpfn_cfg_file = tabpfn_cfg_dir / "config.json"
if not tabpfn_cfg_file.exists():
    with open(tabpfn_cfg_file, "w") as f:
        json.dump({"terms_accepted": True}, f)
os.environ["TABPFN_ACCEPT_TERMS"] = "1"
os.environ["TABPFN_TOKEN"] = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjoiMTZiZWFkMDctMWRkNy00ZjU1LWE4YTUtN2M2NmRlZDU1OWRkIiwiZXhwIjoxODA3MjQ1MzM1fQ.a57geeP_IfY3M6yUDxW6iqPS0tPB6L3u-LB49pCRdgA"
os.environ["CUDA_LAUNCH_BLOCKING"] = "1"   # ← primera línea absoluta
os.environ["TORCH_USE_CUDA_DSA"]   = "1"
import copy
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
import seaborn as sns
sns.set(style="whitegrid")
from transformers import AutoTokenizer, AutoModel
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler
from tabpfn import TabPFNClassifier
from sklearn.metrics import (
    accuracy_score, f1_score, roc_auc_score,
    precision_score, recall_score,
    brier_score_loss, roc_curve,
    confusion_matrix, matthews_corrcoef,
    classification_report
)
import warnings
warnings.filterwarnings("ignore")

# ---------------------------------------------------------------------------
# CONFIG — todos los hiperparámetros en un solo lugar
# ---------------------------------------------------------------------------

device          = "cuda" if torch.cuda.is_available() else "cpu"
model_name      = "microsoft/BiomedNLP-PubMedBERT-base-uncased-abstract-fulltext"
MAX_LEN         = 128
N_SPLITS        = 5
EPOCHS          = 100
BATCH_SIZE      = 16        # mini-batches para mejor generalización
PATIENCE        = 5        # early stopping: epochs sin mejora antes de parar
LR_BERT         = 1e-5      # lr para BERT (solo si FINETUNE_BERT=True)
LR_MODEL        = 1e-4      # lr para el resto del modelo
POS_WEIGHT_MULT = 1.0       # multiplicador sobre el ratio natural (1.0 = sin cambio)
FINETUNE_BERT   = False     # True = fine-tune layer 11 | False = BERT congelado
RANDOM_SEED     = 42
FEATURES        = ["Edad", "NIHSS ingreso", "Fibrilación Auricular", "Hipertensión"]
TARGET          = "mRS egreso"
TABPFN_EMB_DIM = None 

print(f"Device        : {device}")
print(f"Fine-tune BERT: {FINETUNE_BERT}")
print(f"Batch size    : {BATCH_SIZE}")
print(f"Patience      : {PATIENCE}")
print(f"pos_weight x  : {POS_WEIGHT_MULT}")

# ---------------------------------------------------------------------------
# 1. CARGA DE TEXTOS
# ---------------------------------------------------------------------------

def load_clinical_texts(base_path):
    records = []
    for patient in os.listdir(base_path):
        fp = os.path.join(base_path, patient, "ses-01",
            "pretreatment_clinical_imaging_summary.txt")
        if os.path.exists(fp):
            with open(fp, "r", encoding="utf-8") as f:
                records.append({"Paciente_id": patient, "text": f.read().strip()})
    return pd.DataFrame(records)

# ---------------------------------------------------------------------------
# 2. BERT
# ---------------------------------------------------------------------------

print(f"\nCargando {model_name}...")
tokenizer  = AutoTokenizer.from_pretrained(model_name)
bert_model = AutoModel.from_pretrained(model_name).to(device)

if FINETUNE_BERT:
    # Solo última capa entrenable
    for name, param in bert_model.named_parameters():
        param.requires_grad = "encoder.layer.11" in name
    print(f"Parámetros entrenables BERT: "
        f"{sum(p.numel() for p in bert_model.parameters() if p.requires_grad):,}")
else:
    # Completamente congelado — más estable con datasets pequeños
    for param in bert_model.parameters():
        param.requires_grad = False
    print("BERT completamente congelado.")

bert_original_state = copy.deepcopy(bert_model.state_dict())

# ---------------------------------------------------------------------------
# 3. ARQUITECTURA TABULAR
# ---------------------------------------------------------------------------

class TabPFNFeatureEmbedder:
    def __init__(self, device="cpu", layer_name="feature_group_embedder"):
        self.device = device
        self.layer_name = layer_name
        self.clf = TabPFNClassifier(
            device=device,
            ignore_pretraining_limits=True
        )
        self._n_train = 0

    def _internal_model(self):
        for attr in ("model_", "model", "base_model", "network"):
            m = getattr(self.clf, attr, None)
            if isinstance(m, nn.Module):
                return m
        raise RuntimeError("No se encontró modelo interno de TabPFN")

    def fit(self, X, y):
        self.clf.fit(X, y)
        self._n_train = X.shape[0]
        return self

    def transform(self, X):
        model = self._internal_model()
        buffer = {}
        n_test = X.shape[0]

        target = dict(model.named_modules()).get(self.layer_name)
        if target is None:
            raise ValueError(f"Capa '{self.layer_name}' no encontrada")

        def hook_fn(module, inp, out):
            if isinstance(out, torch.Tensor):
                buffer["emb"] = out.detach().cpu()
            elif isinstance(out, (tuple, list)):
                buffer["emb"] = out[0].detach().cpu()

        hook = target.register_forward_hook(hook_fn)

        with torch.no_grad():
            _ = self.clf.predict_proba(X)

        hook.remove()

        raw = buffer["emb"]

        #  MISMA LÓGICA QUE YA VALIDASTE
        if raw.dim() == 3:
            raw = raw[-n_test:]              # (n_test, 3, 192)
            raw = raw.reshape(n_test, -1)

        elif raw.dim() == 2 and raw.shape[0] > n_test:
            raw = raw[-n_test:]

        return torch.tensor(raw.numpy(), dtype=torch.float32)
# =============================================
#    Funcion Perdida
# =============================================

class FocalLoss(nn.Module):
    def __init__(self, alpha=0.25, gamma=2.0, reduction="mean"):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction

    def forward(self, logits, targets):
        bce_loss = nn.functional.binary_cross_entropy_with_logits(
            logits, targets, reduction="none"
        )

        probs = torch.sigmoid(logits)
        pt = torch.where(targets == 1, probs, 1 - probs)

        focal_weight = self.alpha * (1 - pt) ** self.gamma
        loss = focal_weight * bce_loss

        if self.reduction == "mean":
            return loss.mean()
        elif self.reduction == "sum":
            return loss.sum()
        else:
            return loss
# ---------------------------------------------------------------------------
# 4. MODELO MULTIMODAL
# ---------------------------------------------------------------------------

class MultimodalModel(nn.Module):
    def __init__(self, tab_emb_dim, text_dim=768, dropout_mod=0.2):
        super().__init__()

        self.dropout_mod = dropout_mod

        #  Cross Attention
        self.cross_tab_to_text = CrossAttention(
            dim_q=tab_emb_dim,
            dim_kv=text_dim
        )

        self.cross_text_to_tab = CrossAttention(
            dim_q=text_dim,
            dim_kv=tab_emb_dim
        )

        #  GATES mejorados
        self.gate_tab = nn.Sequential(
            nn.Linear(tab_emb_dim * 2, tab_emb_dim),
            nn.ReLU(),
            nn.Linear(tab_emb_dim, tab_emb_dim),
            nn.Sigmoid()
        )

        self.gate_text = nn.Sequential(
            nn.Linear(text_dim * 2, text_dim),
            nn.ReLU(),
            nn.Linear(text_dim, text_dim),
            nn.Sigmoid()
        )

        #  Proyección
        self.text_proj = nn.Linear(text_dim, tab_emb_dim)

        #  Normalización (CLAVE)
        self.norm_tab = nn.LayerNorm(tab_emb_dim)
        self.norm_text = nn.LayerNorm(text_dim)

        #  Clasificador principal
        self.classifier = nn.Sequential(
            nn.Linear(tab_emb_dim * 2, 128),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(128, 1)
        )

        #  Clasificador auxiliar (texto)
        self.text_head = nn.Linear(text_dim, 1)

    def forward(self, tab_emb, text_tokens):

        # =====================================
        #  MODALITY DROPOUT (CRÍTICO)
        # =====================================
        if self.training:
            if torch.rand(1).item() < self.dropout_mod:
                tab_emb = torch.zeros_like(tab_emb)

            if torch.rand(1).item() < self.dropout_mod:
                text_tokens = torch.zeros_like(text_tokens)

        # =====================================
        # 1. TAB → TEXT
        # =====================================
        text_context = self.cross_tab_to_text(tab_emb, text_tokens)

        gate_tab_input = torch.cat([tab_emb, text_context], dim=1)
        gate_tab = self.gate_tab(gate_tab_input)

        tab_fused = (1 - gate_tab) * tab_emb + gate_tab * text_context
        tab_fused = self.norm_tab(tab_fused)

        # =====================================
        # 2. TEXT → TAB
        # =====================================
        text_cls = text_tokens[:, 0, :]

        tab_as_seq = tab_emb.unsqueeze(1)
        tab_context = self.cross_text_to_tab(text_cls, tab_as_seq)

        gate_text_input = torch.cat([text_cls, tab_context], dim=1)
        gate_text = self.gate_text(gate_text_input)

        text_fused = (1 - gate_text) * text_cls + gate_text * tab_context
        text_fused = self.norm_text(text_fused)

        # =====================================
        # 3. PROYECCIÓN + FUSIÓN
        # =====================================
        text_fused_proj = self.text_proj(text_fused)

        fusion = torch.cat([tab_fused, text_fused_proj], dim=1)

        out_main = self.classifier(fusion)

        #  AUX LOSS (texto solo)
        out_text = self.text_head(text_fused)

        return out_main, out_text
# ---------------------------------------------------------------------------
# 5. MÉTRICAS CLÍNICAS
# ---------------------------------------------------------------------------

def compute_metrics(y_true, probs, threshold=0.5):
    preds = (probs > threshold).astype(int)
    cm    = confusion_matrix(y_true, preds, labels=[0, 1])
    tn, fp, fn, tp = cm.ravel()

    sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0.0
    ppv         = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    npv         = tn / (tn + fn) if (tn + fn) > 0 else 0.0

    auc = roc_auc_score(y_true, probs) if len(np.unique(y_true)) > 1 else 0.5

    return {
        "acc":        accuracy_score(y_true, preds),
        "f1":         f1_score(y_true, preds, zero_division=0),
        "auc":        auc,
        "prec":       precision_score(y_true, preds, zero_division=0),
        "rec":        recall_score(y_true, preds, zero_division=0),
        "sens":       sensitivity,
        "spec":       specificity,
        "ppv":        ppv,
        "npv":        npv,
        "mcc":        matthews_corrcoef(y_true, preds),
        "brier":      brier_score_loss(y_true, probs),
        "tp": int(tp), "tn": int(tn), "fp": int(fp), "fn": int(fn),
    }
    
def find_best_threshold_fp_control(y_true, probs, max_fp_rate=0.2):
    thresholds = np.linspace(0.1, 0.9, 200)

    best_t = 0.5
    best_score = -1

    for t in thresholds:
        preds = (probs > t).astype(int)
        tn, fp, fn, tp = confusion_matrix(y_true, preds).ravel()

        fp_rate = fp / (fp + tn + 1e-8)
        recall  = tp / (tp + fn + 1e-8)

        if fp_rate <= max_fp_rate:
            if recall > best_score:
                best_score = recall
                best_t = t

    return best_t

def find_best_threshold_pre(y_true, probs, min_precision=0.65):
    thresholds = np.linspace(0.1, 0.9, 100)
    best_t = 0.5
    best_rec = 0

    for t in thresholds:
        preds = (probs > t).astype(int)
        prec = precision_score(y_true, preds, zero_division=0)
        rec  = recall_score(y_true, preds)

        if prec >= min_precision and rec > best_rec:
            best_rec = rec
            best_t = t

    return best_t

def find_best_threshold_f1(y_true, probs):
    thresholds = np.linspace(0.1, 0.9, 100)
    f1s = [f1_score(y_true, (probs > t).astype(int)) for t in thresholds]
    return thresholds[np.argmax(f1s)]

# ── Modelo "eager" para extracción de atenciones (se carga una sola vez) ──────
_bert_eager = None

def _get_bert_eager():
    """Carga (o reutiliza) una copia del modelo con attn_implementation='eager'."""
    global _bert_eager
    if _bert_eager is None:
        print("  [BERT-eager] Cargando copia con attn_implementation='eager'...")
        _bert_eager = AutoModel.from_pretrained(
            model_name,
            attn_implementation="eager"
        ).to(device)
        _bert_eager.load_state_dict(bert_model.state_dict())  # mismos pesos
        _bert_eager.eval()
        for p in _bert_eager.parameters():
            p.requires_grad = False
    return _bert_eager


def get_bert_attention_weights(text, layer_idx=11, head_idx=None):
    """Extrae pesos de atención del [CLS] en layer_idx (implementación eager)."""
    eager = _get_bert_eager()

    inputs = tokenizer(
        text,
        return_tensors="pt",
        truncation=True,
        max_length=MAX_LEN
    ).to(device)

    with torch.no_grad():
        outputs = eager(**inputs, output_attentions=True)

    if outputs.attentions is None:
        raise RuntimeError("outputs.attentions es None incluso con eager.")

    n_layers = len(outputs.attentions)
    layer_idx = min(layer_idx, n_layers - 1)
    print(f"  [BERT-eager] capas={n_layers}, usando capa {layer_idx}")

    attn = outputs.attentions[layer_idx]          # (1, n_heads, L, L)

    if head_idx is not None:
        cls_attn = attn[0, head_idx, 0, :]
    else:
        cls_attn = attn[0, :, 0, :].mean(dim=0)  # promedio todas las cabezas

    tokens  = tokenizer.convert_ids_to_tokens(inputs["input_ids"][0])
    weights = cls_attn.cpu().numpy()
    weights = (weights - weights.min()) / (weights.max() - weights.min() + 1e-8)

    return list(zip(tokens, weights.tolist()))
def get_tabpfn_feature_importance(embedder, X_sample, feature_names, n_permutations=10):
    """Ablación: mide cuánto cambia el embedding al zerear cada columna."""
    baseline = embedder.transform(X_sample)  # (1, D)
    importances = []
    
    for i in range(X_sample.shape[1]):
        deltas = []
        for _ in range(n_permutations):
            X_perturbed = X_sample.copy()
            X_perturbed[:, i] = 0.0  # ablación
            perturbed = embedder.transform(X_perturbed)
            delta = torch.norm(baseline - perturbed, dim=1).mean().item()
            deltas.append(delta)
        importances.append(np.mean(deltas))
    
    # Normalizar a porcentajes
    importances = np.array(importances)
    importances = importances / importances.sum()
    return dict(zip(feature_names, importances.tolist()))

# ---------------------------------------------------------------------------
# 6. UTILIDAD — mini-batches
# ---------------------------------------------------------------------------

def make_batches(n, batch_size, seed=None):
    rng = np.random.default_rng(seed)
    idx = rng.permutation(n)
    return [idx[i: i + batch_size] for i in range(0, n, batch_size)]

class CrossAttention(nn.Module):
    def __init__(self, dim_q, dim_kv, num_heads=4):
        super().__init__()

        self.query_proj = nn.Linear(dim_q, dim_q)
        self.key_proj   = nn.Linear(dim_kv, dim_q)
        self.value_proj = nn.Linear(dim_kv, dim_q)

        self.attn = nn.MultiheadAttention(
            embed_dim=dim_q,
            num_heads=num_heads,
            batch_first=True
        )

    def forward(self, query, context):
        # query: (B, Dq)
        # context: (B, L, Dkv)

        Q = self.query_proj(query).unsqueeze(1)   # (B,1,D)
        K = self.key_proj(context)                # (B,L,D)
        V = self.value_proj(context)              # (B,L,D)

        attn_output, _ = self.attn(Q, K, V)       # (B,1,D)

        return attn_output.squeeze(1)             # (B,D)
    
def precompute_bert_embeddings(input_ids_list, attention_mask_list,
        token_type_ids_list=None):
    bert_model.eval()
    all_emb = []
    batch_size = 16
    n = input_ids_list.shape[0]
    with torch.no_grad():
        for i in range(0, n, batch_size):
            enc = {"input_ids":      input_ids_list[i:i+batch_size],
                "attention_mask": attention_mask_list[i:i+batch_size]}
            if token_type_ids_list is not None:
                enc["token_type_ids"] = token_type_ids_list[i:i+batch_size]
            out = bert_model(**enc)
            all_emb.append(out.last_hidden_state.cpu())
    return torch.cat(all_emb, dim=0)

def get_fold_tokens(idx):
    return {k: v[idx].to(device) for k, v in all_tokens.items()}
# ---------------------------------------------------------------------------
# 7. MAIN
# ---------------------------------------------------------------------------

if __name__ == "__main__":

    df = pd.read_csv("./df_train_acv.csv")
    df[TARGET] = pd.to_numeric(df[TARGET], errors="coerce")
    df = df.dropna()
    df["mRS_bin"] = (df[TARGET] > 2).astype(int)
    
    text_val_df = load_clinical_texts("../acv_split/val/rawdata")
    df_val   = pd.read_csv("./df_val_acv.csv")
    df_val[TARGET] = pd.to_numeric(df_val[TARGET], errors="coerce")
    df_val = df_val.dropna()
    df_val["mRS_bin"] = (df_val[TARGET] > 2).astype(int)

    df_val = df_val.merge(text_val_df, on="Paciente_id")

    text_df = load_clinical_texts("../acv_split/train/rawdata")
    df      = df.merge(text_df, on="Paciente_id")
    
    
    
    print(f"\nPacientes finales: {len(df)}")
    print(f"Distribución mRS_bin:\n{df['mRS_bin'].value_counts()}")
    ratio = (df["mRS_bin"] == 0).sum() / (df["mRS_bin"] == 1).sum()
    print(f"Ratio desbalance: {ratio:.2f}:1")

    X_tab = df[FEATURES].values.astype(np.float32)
    y     = df["mRS_bin"].values
    texts = df["text"].tolist()
    # Tokenización global (una sola vez)
    print("\nTokenizando textos...")
    all_tokens = tokenizer(texts, padding=True, truncation=True,
        max_length=MAX_LEN, return_tensors="pt")
    tokens_val = tokenizer(
    df_val["text"].tolist(),
    padding=True,
    truncation=True,
    max_length=MAX_LEN,
    return_tensors="pt"
    )
    # ============================================================
    # PRECOMPUTE VAL EXTERNO (una sola vez)
    # ============================================================

    X_val_ext_tab = df_val[FEATURES].values.astype(np.float32)
    y_val_ext     = df_val["mRS_bin"].values

    tokens_val_ext = {k: v.to(device) for k, v in tokens_val.items()}

    emb_val_fixed = precompute_bert_embeddings(
        tokens_val_ext["input_ids"],
        tokens_val_ext["attention_mask"],
        tokens_val_ext.get("token_type_ids", None)
    ).to(device)

    skf        = StratifiedKFold(n_splits=N_SPLITS, shuffle=True, random_state=RANDOM_SEED)
    results    = []
    all_f1     = []
    all_auc    = []
    all_tr_loss  = []
    all_val_loss = []
    all_probs  = []
    all_y_val  = []
    all_epochs_run = []
    saved_models = []
    saved_scalers = []
    saved_tabpfn_embedders = []

    for fold, (train_idx, val_idx) in enumerate(skf.split(X_tab, y)):
        print(f"\n========== Fold {fold+1}/{N_SPLITS} ==========")

        # Reinicio de BERT
        if FINETUNE_BERT:
            bert_model.load_state_dict(copy.deepcopy(bert_original_state))

        # Split tabular
        X_train, X_val = X_tab[train_idx], X_tab[val_idx]
        y_train, y_val = y[train_idx], y[val_idx]

        scaler  = StandardScaler()
        X_train = scaler.fit_transform(X_train)
        X_val   = scaler.transform(X_val)
        
        X_val_ext_scaled = scaler.transform(X_val_ext_tab)
        
        embedder = TabPFNFeatureEmbedder(
            device="cuda",
            layer_name="feature_group_embedder"
        )

        embedder.fit(X_train, y_train)
        
        saved_tabpfn_embedders.append(copy.deepcopy(embedder))

        tab_emb_tr = embedder.transform(X_train)    
        tab_emb_vl = embedder.transform(X_val)
        tab_emb_val_ext = embedder.transform(X_val_ext_scaled)
        
        # NORMALIZACIÓN L2 (fila a fila)
        tab_emb_tr = tab_emb_tr / (tab_emb_tr.norm(dim=1, keepdim=True) + 1e-8)
        tab_emb_vl = tab_emb_vl / (tab_emb_vl.norm(dim=1, keepdim=True) + 1e-8)
        tab_emb_val_ext = tab_emb_val_ext / (tab_emb_val_ext.norm(dim=1, keepdim=True) + 1e-8)

        # Luego ya pasas a GPU
        tab_emb_tr = tab_emb_tr.to(device)
        tab_emb_val_ext = tab_emb_val_ext.to(device)
        
        if TABPFN_EMB_DIM is None:
            TABPFN_EMB_DIM = tab_emb_tr.shape[1]
            print(f"  TabPFN emb_dim detectado: {TABPFN_EMB_DIM}")

        tab_emb_tr      = tab_emb_tr.to(device)
        tab_emb_vl      = tab_emb_vl.to(device)
        tab_emb_val_ext = tab_emb_val_ext.to(device)

        y_tr_t = torch.tensor(y_train, dtype=torch.float32).view(-1, 1).to(device)
        y_vl_t = torch.tensor(y_val,   dtype=torch.float32).view(-1, 1).to(device)

        ratio_fold = (y_train == 0).sum() / max((y_train == 1).sum(), 1)
        pos_weight = torch.tensor(
            [ratio_fold * POS_WEIGHT_MULT], dtype=torch.float32).to(device)

        tokens_tr = get_fold_tokens(train_idx)
        tokens_vl = get_fold_tokens(val_idx)

        # Si BERT está congelado, pre-calculamos embeddings una sola vez
        if not FINETUNE_BERT:
            emb_tr_fixed = precompute_bert_embeddings(
                tokens_tr["input_ids"], tokens_tr["attention_mask"],
                tokens_tr.get("token_type_ids")).to(device)
            emb_vl_fixed = precompute_bert_embeddings(
                tokens_vl["input_ids"], tokens_vl["attention_mask"],
                tokens_vl.get("token_type_ids")).to(device)

        model = MultimodalModel(tab_emb_dim=TABPFN_EMB_DIM).to(device)
        criterion = FocalLoss(alpha=0.6, gamma=1.7, reduction="mean")
        
        if FINETUNE_BERT:
            optimizer = torch.optim.AdamW([
                {"params": filter(lambda p: p.requires_grad, bert_model.parameters()),
                "lr": LR_BERT},
                {"params": model.parameters(), "lr": LR_MODEL}
            ], weight_decay=1e-3)
        else:
            optimizer = torch.optim.AdamW(model.parameters(),
                lr=LR_MODEL, weight_decay=1e-2)

        # Early stopping
        best_val_loss = float("inf")
        patience_counter = 0
        best_model_state = None

        fold_f1, fold_auc, fold_tr_loss, fold_val_loss = [], [], [], []
        
        #print(f"  tab_emb_tr : {tab_emb_tr.shape}  device={tab_emb_tr.device}")
        #print(f"  emb_tr_fixed: {emb_tr_fixed.shape} device={emb_tr_fixed.device}")
        #print(f"  y_tr_t     : {y_tr_t.shape}  device={y_tr_t.device}")
        #print(f"  TABPFN_EMB_DIM={TABPFN_EMB_DIM}")

        for epoch in range(EPOCHS):

            # ── TRAIN (mini-batches) ────────────────────────────────────────
            model.train()
            if FINETUNE_BERT:
                bert_model.train()

            epoch_loss = 0.0
            batches = make_batches(len(train_idx), BATCH_SIZE, seed=epoch)

            for batch_idx in batches:
                optimizer.zero_grad()

                text_tokens_b = emb_tr_fixed[batch_idx]   # (B, L, 768)
                out_main, out_text = model(tab_emb_tr[batch_idx], text_tokens_b)

                loss_main = criterion(out_main, y_tr_t[batch_idx])
                loss_text = criterion(out_text, y_tr_t[batch_idx])

                loss_b = loss_main 
                loss_b.backward()
                optimizer.step()
                epoch_loss += loss_b.item()

            avg_train_loss = epoch_loss / len(batches)
            fold_tr_loss.append(avg_train_loss)

            # ── VALIDACIÓN ─────────────────────────────────────────────────
            model.eval()
            if FINETUNE_BERT:
                bert_model.eval()

            with torch.no_grad():
                text_tokens_vl = emb_vl_fixed   # (N_val, L, 768)
                out_main, _ = model(tab_emb_vl, text_tokens_vl)

                val_loss = criterion(out_main, y_vl_t)
                probs = torch.sigmoid(out_main).cpu().numpy().flatten()

            fold_f1.append(f1_score(y_val, (probs > 0.5).astype(int), zero_division=0))
            fold_auc.append(roc_auc_score(y_val, probs)
                            if len(np.unique(y_val)) > 1 else 0.5)
            fold_val_loss.append(val_loss.item())

            # ── EARLY STOPPING ─────────────────────────────────────────────
            if val_loss.item() < best_val_loss:
                best_val_loss    = val_loss.item()
                patience_counter = 0
                best_model_state = copy.deepcopy(model.state_dict())
            else:
                patience_counter += 1
                if patience_counter >= PATIENCE:
                    print(f"  Early stop en epoch {epoch+1}")
                    break

        all_epochs_run.append(epoch + 1)

        # Restauramos el mejor modelo del fold
        model.load_state_dict(best_model_state)
        saved_models.append(copy.deepcopy(model.state_dict()))
        saved_scalers.append(copy.deepcopy(scaler))
        model.eval()
        if FINETUNE_BERT:
            bert_model.eval()

        with torch.no_grad():
            text_tokens_vl = emb_vl_fixed
            final_out, _ = model(tab_emb_vl, text_tokens_vl)
            final_probs = torch.sigmoid(final_out).cpu().numpy().flatten()

        best_thr = find_best_threshold_f1(y_val, final_probs)
        fold_metrics = compute_metrics(y_val, final_probs, threshold=best_thr)
        fold_metrics["thresh_used"] = best_thr
        results.append(fold_metrics)
        all_f1.append(fold_f1)
        all_auc.append(fold_auc)
        all_tr_loss.append(fold_tr_loss)
        all_val_loss.append(fold_val_loss)
        all_probs.extend(final_probs.tolist())
        all_y_val.extend(y_val.tolist())

        print(f"  Epochs corridos : {epoch+1} ")
        print(f"  Acc={fold_metrics['acc']:.3f} | F1={fold_metrics['f1']:.3f} | "
            f"AUC={fold_metrics['auc']:.3f}")
        print(f"  Sens={fold_metrics['sens']:.3f} | Spec={fold_metrics['spec']:.3f} | "
            f"PPV={fold_metrics['ppv']:.3f} | NPV={fold_metrics['npv']:.3f}")
        print(f"  MCC={fold_metrics['mcc']:.3f} | Brier={fold_metrics['brier']:.3f}")
        print(f"  Matriz: TP={fold_metrics['tp']} TN={fold_metrics['tn']} "
            f"FP={fold_metrics['fp']} FN={fold_metrics['fn']}")

    # ---------------------------------------------------------------------------
    # RESULTADOS FINALES
    # ---------------------------------------------------------------------------

    print(f"\n{'='*55}")
    print(f"  PubMedBERT + TabularTransformer v3")
    print(f"  BERT congelado={not FINETUNE_BERT} | "
        f"pos_weight x{POS_WEIGHT_MULT} | patience={PATIENCE}")
    print(f"  Epochs promedio: {np.mean(all_epochs_run):.1f} ± {np.std(all_epochs_run):.1f}")
    print(f"{'='*55}")

    metricas_reporte = [
        ("ACC",   "acc"),   ("F1",    "f1"),   ("AUC",  "auc"),
        ("SENS",  "sens"),  ("SPEC",  "spec"),
        ("PPV",   "ppv"),   ("NPV",   "npv"),
        ("MCC",   "mcc"),   ("BRIER", "brier"),
    ]

    for label, key in metricas_reporte:
        vals = [r[key] for r in results]
        print(f"  {label:6s}: {np.mean(vals):.4f} ± {np.std(vals):.4f}")

    thr_global = find_best_threshold_f1(all_y_val, np.array(all_probs))
    print(f"\n  Umbral  usado: {thr_global}")

    preds_global = (np.array(all_probs) > thr_global).astype(int)
    print(f"\n  Classification report global (umbral={thr_global:.3f}):")
    print(classification_report(all_y_val, preds_global,
                                target_names=["buen outcome (0)", "mal outcome (1)"]))
    #======================
    #VALIDACIÓN EXTERNA
    #==========================
    print("\n" + "="*60)
    print("        VALIDACIÓN EXTERNA (ENSEMBLE)")
    print("="*60)

    probs_ensemble = []

    for state, scaler, embedder in zip(saved_models, saved_scalers, saved_tabpfn_embedders):
        X_val_scaled = scaler.transform(X_val_ext_tab)

        # Re-extraer embeddings TabPFN del fold
        emb_tab_ext = embedder.transform(X_val_scaled)

        # NORMALIZAR TAMBIÉN AQUÍ
        emb_tab_ext = emb_tab_ext / (emb_tab_ext.norm(dim=1, keepdim=True) + 1e-8)

        emb_tab_ext = emb_tab_ext.to(device)
    # ─────────────────────────────────────────────────────────────────

        model_ext = MultimodalModel(tab_emb_dim=TABPFN_EMB_DIM).to(device)
        model_ext.load_state_dict(state)
        model_ext.eval()

        with torch.no_grad():
            out, _ = model_ext(emb_tab_ext, emb_val_fixed)
            probs = torch.sigmoid(out).cpu().numpy().flatten()

        probs_ensemble.append(probs)

    # Promedio ensemble
    probs_final = np.mean(probs_ensemble, axis=0)

    # Métricas
    metrics_ext = compute_metrics(y_val_ext, probs_final, threshold=thr_global)

    print("\nResultados VALIDACIÓN EXTERNA:")
    for k, v in metrics_ext.items():
        print(f"{k}: {v}")
    # ---------------------------------------------------------------------------
    # GRÁFICAS
    # ---------------------------------------------------------------------------

    # Alineamos curvas al fold más corto (por early stopping)
    min_ep = min(len(x) for x in all_tr_loss)
    mean_tr  = np.mean([x[:min_ep] for x in all_tr_loss],  axis=0)
    mean_val = np.mean([x[:min_ep] for x in all_val_loss], axis=0)
    mean_f1  = np.mean([x[:min_ep] for x in all_f1],       axis=0)
    mean_auc = np.mean([x[:min_ep] for x in all_auc],      axis=0)
    ep       = range(min_ep)

    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    fig.suptitle(f"PubMedBERT + TabularTransformer v3 "
                f"(BERT_frozen={not FINETUNE_BERT}, pw_mult={POS_WEIGHT_MULT})",
                fontsize=12)

    axes[0].plot(ep, mean_tr,  label="Train loss")
    axes[0].plot(ep, mean_val, label="Val loss")
    axes[0].set(title="Loss (promedio K-Fold)", xlabel="Epoch", ylabel="Loss")
    axes[0].legend()

    axes[1].plot(ep, mean_f1,  label="F1")
    axes[1].plot(ep, mean_auc, label="AUC")
    axes[1].set(title="Métricas val (promedio K-Fold)", xlabel="Epoch", ylabel="Score")
    axes[1].legend()

    fpr_g, tpr_g, _ = roc_curve(all_y_val, all_probs)
    auc_global = roc_auc_score(all_y_val, all_probs)
    axes[2].plot(fpr_g, tpr_g, label=f"ROC global (AUC={auc_global:.3f})")
    axes[2].plot([0, 1], [0, 1], "k--", alpha=0.4)
    axes[2].set(title="Curva ROC global", xlabel="1 - Especificidad",
                ylabel="Sensibilidad")
    axes[2].legend()

    plt.tight_layout()
    plt.savefig("curvas_multimodal_v3.png", dpi=150)
    plt.show()
    
    # ---------------------------------------------------------------------------
    # 8. MAPAS DE ACTIVACIÓN — paciente ejemplo de validación externa
    # ---------------------------------------------------------------------------
    print("\n" + "="*60)
    print("        MAPAS DE ACTIVACIÓN (paciente idx=0 de val ext)")
    print("="*60)

    # ── Elige el paciente a inspeccionar ──────────────────────────────────────
    PATIENT_IDX = 0   # <-- cambia este índice para ver otro paciente

    patient_text      = df_val["text"].iloc[PATIENT_IDX]
    patient_tab       = X_val_ext_tab[[PATIENT_IDX]]          # shape (1, 4)
    patient_id        = df_val["Paciente_id"].iloc[PATIENT_IDX]
    patient_label     = df_val["mRS_bin"].iloc[PATIENT_IDX]
    patient_prob      = float(probs_final[PATIENT_IDX])

    print(f"\nPaciente : {patient_id}")
    print(f"Label    : {patient_label}  (1 = mal outcome)")
    print(f"Prob ensemble: {patient_prob:.3f}")

    # ── 8a. Atención BERT — plots por capa ───────────────────────────────────
    import matplotlib.pyplot as plt
    import matplotlib.colors as mcolors
    import matplotlib.patches as mpatches

    def plot_bert_attention(text, layers=[8, 10, 11], top_n=25,
                        save_path="bert_attention_{patient_id}.png"):

        import matplotlib.pyplot as plt
        import matplotlib.patches as FancyBboxPatch
        from matplotlib.patches import FancyBboxPatch as FBP
        import numpy as np

    # ── Paleta: azul frío (baja) → naranja/coral (alta) ──────────────────────
        def weight_to_rgb(w):
            lo = np.array([0.18, 0.22, 0.32])   # azul oscuro
            hi = np.array([0.85, 0.35, 0.19])   # coral/naranja
            c  = lo + (hi - lo) * w
            return tuple(c)

        def text_color(w):
            return (1.0, 1.0, 1.0) if w > 0.45 else (0.75, 0.82, 0.92)

        n_layers = len(layers)
        fig, axes = plt.subplots(n_layers, 1,
                             figsize=(14, 3.6 * n_layers),
                             facecolor="#111827")

        if n_layers == 1:
            axes = [axes]

        eager = _get_bert_eager()

        for row, layer in enumerate(layers):
            inputs = tokenizer(text, return_tensors="pt",
                           truncation=True, max_length=MAX_LEN).to(device)

            with torch.no_grad():
                outputs = eager(**inputs, output_attentions=True)

            attn   = outputs.attentions[layer]
            tokens = tokenizer.convert_ids_to_tokens(inputs["input_ids"][0])

            cls_row = attn[0, :, 0, :].mean(dim=0).cpu().numpy()
            w_norm  = (cls_row - cls_row.min()) / (cls_row.max() - cls_row.min() + 1e-8)

            ax = axes[row]
            ax.set_facecolor("#111827")
            ax.set_xlim(0, 1)
            ax.set_ylim(0, 1)
            ax.axis("off")

            # ── Disposición fluida de tokens (word-wrap) ──────────────────────────
            pad_x    = 0.012
            pad_y    = 0.010
            tok_h    = 0.13          # altura de cada pastilla (fracción del eje)
            gap_x    = 0.008
            gap_y    = 0.055
            font_sz  = 7.5
            x_cursor = pad_x
            y_cursor = 0.92          # empieza arriba

            # Calculamos ancho aproximado de cada token en fracción del eje
            # (14 pulgadas de ancho → ~1 char ≈ 0.009 del eje)
            char_w   = 0.0085

            for tok, w in zip(tokens, w_norm):
                tok_display = tok.replace("▁", "").replace("Ġ", " ").strip() or tok
                tok_w       = max(len(tok_display) * char_w + pad_x * 2, 0.035)

                # Salto de línea si no cabe
                if x_cursor + tok_w > 1.0 - pad_x:
                    x_cursor  = pad_x
                    y_cursor -= (tok_h + gap_y)

                if y_cursor < 0.02:   # por si el texto es muy largo
                    break

                fc = weight_to_rgb(w)
                tc = text_color(w)

                # Dibuja la pastilla
                rect = FBP(
                    (x_cursor, y_cursor - tok_h),
                    tok_w, tok_h,
                    boxstyle="round,pad=0.01",
                    facecolor=fc,
                    edgecolor=(1,1,1,0.08),
                    linewidth=0.4,
                    zorder=2
                )
                ax.add_patch(rect)

            # Texto centrado en la pastilla
                ax.text(
                    x_cursor + tok_w / 2,
                    y_cursor - tok_h / 2,
                    tok_display,
                    ha="center", va="center",
                    fontsize=font_sz,
                    color=tc,
                    fontfamily="monospace",
                    zorder=3
                )

                x_cursor += tok_w + gap_x

            # ── Título de la capa ─────────────────────────────────────────────────
            ax.set_title(f"Capa {layer}  —  atención [CLS] → tokens  "
                    f"(promedio 12 cabezas)",
                    color="white", fontsize=10, pad=6,
                    loc="left", x=0.01)

        # ── Barra de leyenda ──────────────────────────────────────────────────
            legend_x = np.linspace(0.01, 0.22, 100)
            legend_y = 0.03
            for i, lx in enumerate(legend_x):
                ww = i / 99
                ax.add_patch(plt.Rectangle(
                    (lx, legend_y - 0.015), 0.002, 0.025,
                    color=weight_to_rgb(ww), zorder=1
                ))
            ax.text(0.005, legend_y - 0.004, "Baja activación",
                color="#8899aa", fontsize=7, va="center")
            ax.text(0.225, legend_y - 0.004, "Alta activación",
                color="#ccddee", fontsize=7, va="center")

        fig.suptitle(
            f"Mapas de atención BERT  ·  {patient_id}  "
            f"|  Prob. mal outcome: {patient_prob:.1%}  |  Label: {patient_label}",
            color="white", fontsize=12, y=1.01, x=0.01, ha="left"
        )
        plt.tight_layout(h_pad=1.2)
        path = save_path.format(patient_id=patient_id)
        plt.savefig(path, dpi=160, bbox_inches="tight", facecolor="#111827")
        print(f"  Guardado: {path}")
        plt.show()


    # ── 8b. Importancia TabPFN — plot ─────────────────────────────────────────
    def plot_tabpfn_importance(mean_imp, patient_tab, feature_names,
                               patient_id, patient_prob, patient_label,
                               save_path="tabpfn_importance_{patient_id}.png"):

        feats   = list(feature_names)
        imps    = [mean_imp[f] for f in feats]
        vals    = [patient_tab[0, i] for i in range(len(feats))]

        # Orden descendente
        order   = np.argsort(imps)
        feats_s = [feats[i] for i in order]
        imps_s  = [imps[i]  for i in order]
        vals_s  = [vals[i]  for i in order]

        # Color: rojo para las features de mayor importancia, verde para menores
        # (sin ground-truth de dirección — usa el ranking relativo)
        norm_imp = np.array(imps_s) / max(imps_s)
        colors   = [plt.cm.RdYlGn_r(v * 0.85 + 0.05) for v in norm_imp]

        fig, ax = plt.subplots(figsize=(9, 5))
        bars = ax.barh(range(len(feats_s)), imps_s, color=colors, height=0.55)

        # Etiqueta: nombre + valor real del paciente
        labels = [f"{f}  [val = {v:.1f}]" for f, v in zip(feats_s, vals_s)]
        ax.set_yticks(range(len(feats_s)))
        ax.set_yticklabels(labels, fontsize=11)

        # Porcentaje dentro/fuera de la barra
        for bar, imp in zip(bars, imps_s):
            ax.text(imp + 0.003, bar.get_y() + bar.get_height() / 2,
                    f"{imp*100:.1f}%", va="center", fontsize=10,
                    color="#333333")

        ax.set_xlabel("Importancia relativa (ablación, promedio 5 folds)", fontsize=10)
        ax.set_title(
            f"Importancia de features TabPFN — {patient_id}\n"
            f"Prob. mal outcome: {patient_prob:.2%}  |  Label: {patient_label}",
            fontsize=12, pad=10
        )
        ax.set_xlim(0, max(imps_s) * 1.25)
        ax.spines[["top", "right"]].set_visible(False)

        # Leyenda de color
        patch_hi = mpatches.Patch(color=plt.cm.RdYlGn_r(0.9), label="Mayor importancia")
        patch_lo = mpatches.Patch(color=plt.cm.RdYlGn_r(0.1), label="Menor importancia")
        ax.legend(handles=[patch_hi, patch_lo], fontsize=9,
                  loc="lower right", framealpha=0.5)

        plt.tight_layout()
        path = save_path.format(patient_id=patient_id)
        plt.savefig(path, dpi=150, bbox_inches="tight")
        print(f"  Guardado: {path}")
        plt.show()
    # ── Calcular importancia promediada sobre los 5 folds ─────────────────────
    scaler_0   = saved_scalers[0]
    embedder_0 = saved_tabpfn_embedders[0]
    X_patient_scaled = scaler_0.transform(patient_tab)

    importance_dict = get_tabpfn_feature_importance(
        embedder=embedder_0,
        X_sample=X_patient_scaled,
        feature_names=FEATURES,
        n_permutations=20
    )

    all_imps = []
    for scaler_k, embedder_k in zip(saved_scalers, saved_tabpfn_embedders):
        X_k   = scaler_k.transform(patient_tab)
        imp_k = get_tabpfn_feature_importance(
            embedder_k, X_k, FEATURES, n_permutations=10
        )
        all_imps.append(imp_k)

    mean_imp = {
        feat: float(np.mean([d[feat] for d in all_imps]))
        for feat in FEATURES
    }

    # ── Ahora sí se puede llamar al plot ──────────────────────────────────────
    plot_tabpfn_importance(mean_imp, patient_tab, FEATURES,
                           patient_id, patient_prob, patient_label)
    